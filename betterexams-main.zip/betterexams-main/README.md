# Better Exams
(A working title)

# Why?
The official [examinations.ie](https://www.examinations.ie) site is an abhorrent abomination that manages to break every UX rule. (I mean seriously, selecting Exam Papers or Marking Schemes first, really?!) This also was a way to improve my React skills. I've learnt a lot in the course of this project, and I hope that anybody wishing to emulate it will too.

# Contribution
If for any reason you want to make a change, feel free to open up a pull request and I'll try to get back to you as soon as possible. It's greatly appreciated! Just be warned that I have given up any hope of keeping this thing optimised. Send me a message on Discord (general.mudkip) if you've got any questions.

# Credits
This was heavily inspired by [examfinder.ie](https://examfinder.ie/) by Thomas Forbes. Many thanks to him for allowing me to use his data.json file.
